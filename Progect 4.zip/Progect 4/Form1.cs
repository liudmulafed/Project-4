﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progect_4
{
    public partial class Form1 : Form
    {
        List<Article> articles = new List<Article>();

        public Form1()
        {
            InitializeComponent();
        }
        public class Article
        {
            public string Author { get; set; }
            public int Pages { get; set; }
            public string Title { get; set; }
            public string Topic { get; set; }
            public DateTime Date { get; set; }
            public string Place { get; set; }
            public string Language { get; set; }
            public int Year { get; set; }

            public override string ToString()
            {
                return
                    $"Автор: {Author}\n" +
                    $"Кількість сторінок: {Pages}\n" +
                    $"Назва: {Title}\n" +
                    $"Тема: {Topic}\n" +
                    $"Дата: {Date:dd-MM}\n" +
                    $"Місце: {Place}\n" +
                    $"Мова: {Language}\n" +
                    $"Рік: {Year}\n";
            }
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Article a = new Article
                {
                    Author = textBoxAuthor.Text,
                    Pages = int.Parse(textBoxPages.Text),
                    Title = textBoxTitle.Text,
                    Topic = textBoxTopic.Text,
                    Date = DateTime.Parse(textBoxDate.Text),
                    Place = textBoxPlace.Text,
                    Language = textBoxLanguage.Text,
                    Year = int.Parse(textBoxYear.Text)
                };

                articles.Add(a);

                MessageBox.Show("Статтю успішно додано!", "Готово",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // очищення полів
                foreach (var tb in Controls.OfType<TextBox>())
                    tb.Clear();
            }
            catch
            {
                MessageBox.Show("Помилка! Перевірте правильність введених даних.",
                    "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            if (articles.Count == 0)
            {
                MessageBox.Show("Список порожній.");
                return;
            }

            string output = "";

            foreach (var a in articles)
            {
                output += a.ToString() + "\n----------------------------------------\n";
            }

            MessageBox.Show(output, "Список статей");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
